package com.Wavic.SysD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebWavicD1Application {

	public static void main(String[] args) {
		SpringApplication.run(WebWavicD1Application.class, args);
		System.out.println("#################Spring Boot 80 Startup#################");
		System.out.println("#################AP-Check-CPU/MEM#################");
		System.out.println("#################AP-Resource Check Test#################");
		System.out.println("################1. Connect-AP-Resource Check Test#################");
		System.out.println("################2. Connect-AP-Resource Check Test#################");
		System.out.println("################3.Jenkins TEST_Web Check");
	}

}
