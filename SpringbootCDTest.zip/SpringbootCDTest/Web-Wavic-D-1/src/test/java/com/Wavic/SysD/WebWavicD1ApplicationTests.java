package com.Wavic.SysD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebWavicD1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
